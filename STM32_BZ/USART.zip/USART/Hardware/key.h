#ifndef __KEY_H__
#define __KEY_H__

void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
