#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "Delay.h" 
#include "LED.h"
#include "APP.h"
int main()
{	
     LED_Init();
     
	while(1)
	{      
        APP_turn();  
	}
}
